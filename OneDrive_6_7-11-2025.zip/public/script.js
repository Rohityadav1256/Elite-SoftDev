const socket = io();
const editor = document.getElementById('editor');

editor.addEventListener('input', () => {
  const text = editor.value;
  socket.emit('textChange', text);
});

socket.on('textUpdate', (text) => {
  editor.value = text;
});
